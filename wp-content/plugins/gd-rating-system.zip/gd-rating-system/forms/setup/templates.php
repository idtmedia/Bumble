<h3 style="margin-top: 0"><?php _e("Rating templates", "gd-rating-system"); ?></h3>
<?php

gdrts_rescan_for_templates();

_e("Templates list saved.", "gd-rating-system");
