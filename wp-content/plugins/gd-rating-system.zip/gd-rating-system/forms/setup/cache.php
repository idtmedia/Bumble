<h3><?php _e("Cache Cleanup", "gd-rating-system"); ?></h3>
<?php

gdrts_cache()->clear();

_e("Plugin cache is flushed.", "gd-rating-system");
