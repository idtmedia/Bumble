<?php

include(GDRTS_PATH.'forms/setup/templates.php');
include(GDRTS_PATH.'forms/setup/database.php');
include(GDRTS_PATH.'forms/setup/cache.php');
