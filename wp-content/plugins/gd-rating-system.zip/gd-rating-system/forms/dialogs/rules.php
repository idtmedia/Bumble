<div style="display: none">
    <div title="<?php _e("Are you sure?", "gd-rating-system"); ?>" id="gdrts-dialog-rule-delete">
        <div class="gdrts-inner-content">
            <p><?php _e("Are you sure you want to proceed? This operation is not reversable!", "gd-rating-system"); ?></p>
        </div>
    </div>
</div>