=== Dev4Press Library ===
Version: v2.3.4
Author:  Milan Petrovic
Email:   support@dev4press.com
Website: https://www.dev4press.com/

== General Requirements ==
* PHP: 5.5 or newer
* bbPress 2.5 or newer
* mySQL: 5.5 or newer
* WordPress: 4.4 or newer
