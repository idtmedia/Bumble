<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Жахливо",
        "ratePoor" => "Погано",
        "rateAverage" => "Нормально",
        "rateGood" => "Добре",
        "rateExcellent" => "Прекрасно",
        "rateThis" => "Оцінити",
        "like" => "Цікаво",
        "dislike" => "Нецікаво",
        "vote" => "Оцінка",
        "votes" => "Оцінки",
        "thanks" => "Дякую",
        "outOf" => "з",
        "weRecommend" => "Ми Рекомендуємо",
    );
?>
