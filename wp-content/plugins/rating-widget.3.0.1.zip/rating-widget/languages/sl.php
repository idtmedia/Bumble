<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Zelo slabo",
        "ratePoor" => "Slabo",
        "rateAverage" => "Povprečno",
        "rateGood" => "Dobro",
        "rateExcellent" => "Zelo dobro",
        "rateThis" => "Oceni",
        "like" => "Všeč mi je",
        "dislike" => "Ni mi všeč",
        "vote" => "Glas",
        "votes" => "Glasovi",
        "thanks" => "Hvala",
        "outOf" => "od",
        "weRecommend" => "Vam priporočamo",
    );