<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Okropny",
        "ratePoor" => "Słaby",
        "rateAverage" => "Przeciętny",
        "rateGood" => "Dobry",
        "rateExcellent" => "Wspaniały",
        "rateThis" => "Oceń to",
        "like" => "Lubię",
        "dislike" => "Nie lubię",
        "vote" => "Głosuj",
        "votes" => "Głosy",
        "thanks" => "Dziękuję",
        "outOf" => "z",
        "weRecommend" => "Zalecamy",
    );
?>