<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "可怕",
        "ratePoor" => "坏",
        "rateAverage" => "平均",
        "rateGood" => "好",
        "rateExcellent" => "优秀",
        "rateThis" => "评分",
        "like" => "喜欢",
        "dislike" => "反感",
        "vote" => "投票",
        "votes" => "投票",
        "thanks" => "谢谢",
        "outOf" => "/",
        "weRecommend" => "我们建议",
    );

//    $numbers = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');