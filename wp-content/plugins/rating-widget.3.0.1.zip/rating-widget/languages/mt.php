<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "L-ghar",
        "ratePoor" => "Hazin",
        "rateAverage" => "Insomma",
        "rateGood" => "Tajjeb",
        "rateExcellent" => "Eccelenti",
        "rateThis" => "Ivotta din",
        "like" => "Togobni",
        "dislike" => "Ma togobnix",
        "vote" => "Ivotta",
        "votes" => "Il-votti",
        "thanks" => "Grazzi",
        "outOf" => "barra min",
        "weRecommend" => "Nirikomadilkhom",
    );
?>
