<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Çok Kötü",
        "ratePoor" => "Kötü",
        "rateAverage" => "Orta",
        "rateGood" => "İyi",
        "rateExcellent" => "Mükemmel",
        "rateThis" => "Değerlendir",
        "like" => "Beğen",
        "dislike" => "Beğenme",
        "vote" => "Oyla",
        "votes" => "Oylar",
        "thanks" => "Teşekkürler",
        "outOf" => "üzerinden",
        "weRecommend" => "Biz Tavsiye",
    );
?>