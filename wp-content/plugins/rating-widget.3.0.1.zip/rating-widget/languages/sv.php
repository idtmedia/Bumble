<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Hemskt",
        "ratePoor" => "Dåligt",
        "rateAverage" => "Okej",
        "rateGood" => "Bra",
        "rateExcellent" => "Fantiastiskt",
        "rateThis" => "Betygsätt",
        "like" => "Gilla",
        "dislike" => "Ogilla",
        "vote" => "Röst",
        "votes" => "Röster",
        "thanks" => "Tack",
        "outOf" => "av",
        "weRecommend" => "Vi rekommenderar",
    );
?>
