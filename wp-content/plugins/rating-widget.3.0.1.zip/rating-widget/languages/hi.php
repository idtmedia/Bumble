<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "भयंकर",
        "ratePoor" => "बुरा",
        "rateAverage" => "औसत",
        "rateGood" => "अच्छा",
        "rateExcellent" => "उत्कृष्ट",
        "rateThis" => "इस दर",
        "like" => "तरह",
        "dislike" => "नापसंद",
        "vote" => "वोट",
        "votes" => "वोट",
        "thanks" => "शुक्रिया",
        "outOf" => "से बाहर",
        "weRecommend" => "हम सिफारिश",
    );
?>
