<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "জঘন্য",
        "ratePoor" => "নগণ্য",
        "rateAverage" => "মাঝারি",
        "rateGood" => "ভাল",
        "rateExcellent" => "চমৎকার",
        "rateThis" => "মূল্যায়ন করুন",
        "like" => "পছন্দ",
        "dislike" => "অপছন্দ",
        "vote" => "ভোট",
        "votes" => "সমগ্র ভোট",
        "thanks" => "ধন্যবাদ",
        "outOf" => "খুঁজে",
        "weRecommend" => "আমরা সুপারিশ",
    );
?>
