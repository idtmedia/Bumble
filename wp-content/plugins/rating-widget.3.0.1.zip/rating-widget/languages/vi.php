<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Dở quá",
        "ratePoor" => "Tàm tạm",
        "rateAverage" => "Cũng được",
        "rateGood" => "Hay",
        "rateExcellent" => "Hay quá xá",
        "rateThis" => "Đánh giá",
        "like" => "Thích",
        "dislike" => "Không thích",
        "vote" => "Bình chọn",
        "votes" => "Bình chọn",
        "thanks" => "Cám ơn",
        "outOf" => "trong",
        "weRecommend" => "Chúng tôi Đề nghị",
    );
    
    $numbers = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
