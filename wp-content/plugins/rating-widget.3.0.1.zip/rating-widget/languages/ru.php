<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Ужасный",
        "ratePoor" => "Плохо",
        "rateAverage" => "Среднее",
        "rateGood" => "Хорошее",
        "rateExcellent" => "Отлично",
        "rateThis" => "Голосуй",
        "like" => "Нравится",
        "dislike" => "Не нравится",
        "vote" => "Голос",
        "votes" => "Голосов",
        "thanks" => "Спасибо",
        "outOf" => "из",
        "weRecommend" => "Мы рекомендуем",
    );
?>
