<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "별로예요",
        "ratePoor" => "부족해요",
        "rateAverage" => "보통이예요",
        "rateGood" => "좋아요",
        "rateExcellent" => "훌륭해요",
        "rateThis" => "평가",
        "like" => "좋아요",
        "dislike" => "별로에요",
        "vote" => "투표",
        "votes" => "명이 투표했습니다",
        "thanks" => "감사합니다",
        "outOf" => "점 만점",
        "weRecommend" => "우리는 권장",
    );
?>
