<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Ужасно",
        "ratePoor" => "Слабо",
        "rateAverage" => "Просечно",
        "rateGood" => "Добро",
        "rateExcellent" => "Одлично",
        "rateThis" => "Оцени го ова",
        "like" => "Ми се допаѓа",
        "dislike" => "Не ми се допаѓа",
        "vote" => "Гласај",
        "votes" => "Гласови",
        "thanks" => "Ви благодариме",
        "outOf" => "out of",
        "weRecommend" => "We Recommend",
    );
?>
