<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Terribile",
        "ratePoor" => "Insufficiente",
        "rateAverage" => "Media",
        "rateGood" => "Buono",
        "rateExcellent" => "Eccellente",
        "rateThis" => "Vota",
        "like" => "Mi piace",
        "dislike" => "Non mi piace",
        "vote" => "Vota",
        "votes" => "Voti",
        "thanks" => "Grazie",
        "outOf" => "di",
        "weRecommend" => "Raccomandiamo",
    );