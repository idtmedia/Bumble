<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Ужасно",
        "ratePoor" => "Лошо",
        "rateAverage" => "Средно",
        "rateGood" => "Добро",
        "rateExcellent" => "Страхотно",
        "rateThis" => "Гласувай за",
        "like" => "Харесвам",
        "dislike" => "Не харесвам",
        "vote" => "Гласувай",
        "votes" => "Гласове",
        "thanks" => "Благодарим Ви",
        "outOf" => "от",
        "weRecommend" => "Ние Препоръчай",
    );
?>
