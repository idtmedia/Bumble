<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Verskriklik",
        "ratePoor" => "Bad",
        "rateAverage" => "Gemiddelde",
        "rateGood" => "Goeie",
        "rateExcellent" => "Uitstekend",
        "rateThis" => "Beoordeel hierdie",
        "like" => "Soos",
        "dislike" => "Hou nie",
        "vote" => "Stem",
        "votes" => "Stemme",
        "thanks" => "Dankie dat jy",
        "outOf" => "uit",
        "weRecommend" => "ons beveel aan",
    );
?>
