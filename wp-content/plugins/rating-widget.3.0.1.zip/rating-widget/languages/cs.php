<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Špatné",
        "ratePoor" => "Slabé",
        "rateAverage" => "Průměrné",
        "rateGood" => "Dobré",
        "rateExcellent" => "Výborné",
        "rateThis" => "Ohodnotit",
        "like" => "Líbí se mi",
        "dislike" => "Nelíbí se mi",
        "vote" => "Hlasuj",
        "votes" => "Počet hlasů",
        "thanks" => "Děkujeme",
        "outOf" => "ze",
        "weRecommend" => "Doporučujeme",
    );
?>
