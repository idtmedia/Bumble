<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "საშინელი",
        "ratePoor" => "ცუდი",
        "rateAverage" => "საშუალო",
        "rateGood" => "კარგი",
        "rateExcellent" => "საუკეთესო",
        "rateThis" => "შეაფასეთ",
        "like" => "მომწონს",
        "dislike" => "არ მომწონს",
        "vote" => "ხმის მიცემა",
        "votes" => "ხმათა რაოდენობა",
        "thanks" => "მადლობა",
        "outOf" => "/",
        "weRecommend" => "ჩვენ გირჩევთ",
    );
?>