<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Kohutav",
        "ratePoor" => "Kesine",
        "rateAverage" => "Keskmine",
        "rateGood" => "Hea",
        "rateExcellent" => "Suurepärane",
        "rateThis" => "Hinda seda",
        "like" => "Meeldib",
        "dislike" => "Ei meeldi",
        "vote" => "Hinda",
        "votes" => "Hääli",
        "thanks" => "Täname",
        "outOf" => "out of",
        "weRecommend" => "Soovitame",
    );
?>
