<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Awful",
        "ratePoor" => "Poor",
        "rateAverage" => "Average",
        "rateGood" => "Good",
        "rateExcellent" => "Excellent",
        "rateThis" => "Rate this",
        "like" => "Like",
        "dislike" => "Dislike",
        "vote" => "Vote",
        "votes" => "Votes",
        "thanks" => "Thank You",
        "outOf" => "out of",
        "weRecommend" => "We Recommend",
    );
    
    global $LNG_EN;
    $LNG_EN = $dictionary;
?>
