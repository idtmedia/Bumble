<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Slecht",
        "ratePoor" => "Matig",
        "rateAverage" => "Gemiddeld",
        "rateGood" => "Goed",
        "rateExcellent" => "Perfect",
        "rateThis" => "Beoordeel deze",
        "like" => "Vind ik leuk",
        "dislike" => "Vind ik niet leuk",
        "vote" => "Stem",
        "votes" => "Stemmen",
        "thanks" => "Dank je",
        "outOf" => "van de",
        "weRecommend" => "Wij raden",
    );