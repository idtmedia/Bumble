<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Forfærdeligt",
        "ratePoor" => "Dårlig",
        "rateAverage" => "Middel",
        "rateGood" => "God",
        "rateExcellent" => "Fantastisk",
        "rateThis" => "Rating",
        "like" => "Jeg kan lide det",
        "dislike" => "Jeg kan ikke lide det",
        "vote" => "Stem",
        "votes" => "Stemmer",
        "thanks" => "Tak",
        "outOf" => "ud af",
        "weRecommend" => "Vi anbefaler",
    );
?>
