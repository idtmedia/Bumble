<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Horrible",
        "ratePoor" => "Mal",
        "rateAverage" => "Promedio",
        "rateGood" => "Bueno",
        "rateExcellent" => "Excelente",
        "rateThis" => "Calificar",
        "like" => "Gusta",
        "dislike" => "No gusta",
        "vote" => "Voto",
        "votes" => "Votos",
        "thanks" => "Gracias",
        "outOf" => "de cada",
        "weRecommend" => "Recomendamos",
    );