<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Horrible",
        "ratePoor" => "Mauvais",
        "rateAverage" => "Moyen",
        "rateGood" => "Bonne",
        "rateExcellent" => "Excellent",
        "rateThis" => "Noter",
        "like" => "J'aime",
        "dislike" => "N'aime pas",
        "vote" => "Vote",
        "votes" => "Votes",
        "thanks" => "Merci",
        "outOf" => "sur",
        "weRecommend" => "Nous vous recommandons",
    );
?>
