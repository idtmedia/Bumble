<?php
    $dir = "rtl";
    $hor = "left";
    $dictionary = array(
        "rateAwful" => "افتضاح",
        "ratePoor" => "بد",
        "rateAverage" => "معمولی",
        "rateGood" => "خوب",
        "rateExcellent" => "عالی",
        "rateThis" => "رتبه‌دهی",
        "like" => "پسندیدم",
        "dislike" => "نپسندیدم",
        "vote" => "رأی",
        "votes" => "رأی",
        "thanks" => "ممنون",
        "outOf" => "از",
        "weRecommend" => "پیشنهاد ما",
    );
    
    $numbers = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹');
