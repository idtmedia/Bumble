<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Elégtelen",
        "ratePoor" => "Gyenge",
        "rateAverage" => "Átlagos",
        "rateGood" => "Jó",
        "rateExcellent" => "Kitűnő",
        "rateThis" => "Értékelje",
        "like" => "Tetszik",
        "dislike" => "Nem tetszik",
        "vote" => "Szavazzon",
        "votes" => "Szavazatok",
        "thanks" => "Köszönöm",
        "outOf" => "out of",
        "weRecommend" => "Javasoljuk",
    );
?>
