<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Péssimo",
        "ratePoor" => "Ruim",
        "rateAverage" => "Médio",
        "rateGood" => "Bom",
        "rateExcellent" => "Excelente",
        "rateThis" => "Avalie",
        "like" => "Gosto",
        "dislike" => "Não Gosto",
        "vote" => "Voto",
        "votes" => "Votos",
        "thanks" => "Obrigado",
        "outOf" => "de",
        "weRecommend" => "Recomendamos",
    );
?>
