<?php
    $dir = "ltr";
    $hor = "right";
    $dictionary = array(
        "rateAwful" => "Elendig",
        "ratePoor" => "Dårlig",
        "rateAverage" => "Gjennomsnittlig",
        "rateGood" => "Bra",
        "rateExcellent" => "Utmerket",
        "rateThis" => "Hva synes du om dette",
        "like" => "Liker",
        "dislike" => "Liker ikke",
        "vote" => "Stemme",
        "votes" => "Stemmer",
        "thanks" => "Takk",
        "outOf" => "av",
        "weRecommend" => "Vi anbefaler",
    );