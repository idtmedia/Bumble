<?php
    // Exit if accessed directly.
    if (!defined('ABSPATH')) {
	    exit;
    }
    
    /* Unique-User-Key & API Secret
    -----------------------------------------------------------------------------------------*/
    // You can hardcode your Rating-Widget user-id here (get one from http://rating-widget.com)
    //define('WP_RW__USER_ID', '1234567890');

    // You can hardcode your Rating-Widget unique-user-key here (get one from http://rating-widget.com)
    //define('WP_RW__USER_KEY', 'abcdefghijklmnopqrstuvwzyz123456');

    // You can hardcode your Rating-Widget secret here (only for Pro version - contact vova@rating-widget.com)
    //define('WP_RW__USER_SECRET', 'abcdefghijklmnopqrstuvwzyz123456');