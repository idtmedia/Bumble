<?php
    $theme_options = new stdClass();
    $theme_options->type = "star";
    $theme_options->style = "flat_green";

    $theme = array(
        "name" => "star_flat_green",
        "title" => "Flat Green Stars",
        "options" => $theme_options
    );
?>
