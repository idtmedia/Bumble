<?php
    $theme_options = new stdClass();
    $theme_options->type = "star";
    $theme_options->style = "flat_brown";

    $theme = array(
        "name" => "star_flat_brown",
        "title" => "Flat Brown Stars",
        "options" => $theme_options
    );
?>
